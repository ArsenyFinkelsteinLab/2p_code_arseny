# matRegress
MATLAB code for GLMs on pyschophysical and neural data

The goal of matRegress is to handle flexible regularization of Generalized Linear Models and find the hyperparameters.

UNDER DEVELOPMENT

checkout test_bernoulli_blkdiagonal.m

TODO: uniform grid search of hyperparameters
TODO: fix hyperparameter ranges