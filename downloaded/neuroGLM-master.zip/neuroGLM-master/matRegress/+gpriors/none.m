function Cinv = none(rho, nx)
% no prior
% Cinv = none(rho, nx)

Cinv = zeros(nx);