function trial = newTrial(expt, duration)
% Create a new trial structure to load the variables into Experiment structure

trial = struct();
trial.expt = expt;
trial.duration = duration;
